const mongoose = require('mongoose')
const stuschema = mongoose.Schema({
    rollno: {
        type: String,
        require: true
    },

    name: {
        type: String,
        require: true

    },
    scholarship: {
        type: Boolean,
        require: true
    }








})

module.exports = mongoose.model('student1', stuschema)